<?php
// This file has been deleted.
?>