<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Simple Login System</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>