<?php
$servername = "localhost";
$username = "continualink_statement";
$password = "Kp6Q7pLQGXNdYD66juUM";
$dbname = "continualink_statement";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>