<?php
session_start();
include 'includes/header.php';
?>

<h1>Welcome to the Simple Login System</h1>
<p>Please <a href="login.php">login</a> to continue.</p>

<?php
include 'includes/footer.php';
?>